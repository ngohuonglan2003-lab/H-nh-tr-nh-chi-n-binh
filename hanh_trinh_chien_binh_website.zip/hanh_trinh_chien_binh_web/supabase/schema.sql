-- HÀNH TRÌNH CHIẾN BINH: schema mẫu cho Supabase
-- LƯU Ý: bản SQL này là nền tảng lưu hồ sơ; trước khi dùng với học sinh thật,
-- cần triển khai Edge Function để xác thực PIN, giới hạn thử sai và cấp session an toàn.
create extension if not exists pgcrypto;

create table if not exists public.player_profiles (
  id uuid primary key default gen_random_uuid(),
  nickname text not null,
  nickname_key text not null unique,
  pin_hash text not null,
  stage integer not null default 0 check (stage between 0 and 5),
  gems integer not null default 0,
  armor integer[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.player_journal (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.player_profiles(id) on delete cascade,
  stage integer not null check (stage between 1 and 5),
  title text not null,
  entry text not null,
  created_at timestamptz not null default now()
);

-- Không bật truy cập trực tiếp từ trình duyệt. Chỉ Edge Functions dùng service role.
alter table public.player_profiles enable row level security;
alter table public.player_journal enable row level security;
-- Không tạo policy public. Không đưa service_role key vào mã trình duyệt.
