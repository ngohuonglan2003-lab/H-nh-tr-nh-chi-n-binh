# Hành Trình Chiến Binh — Website game

## Có gì trong bộ này
- Game HTML5 chạy trên trình duyệt điện thoại, tablet và máy tính.
- Điều khiển cảm ứng và bàn phím.
- 5 chặng, vật cản, nhân vật di chuyển, vật phẩm, trái tim, bộ giáp.
- Câu hỏi tự suy ngẫm và nhật ký cá nhân.
- Hồ sơ PIN ở chế độ hiện tại lưu cục bộ trên thiết bị/trình duyệt.

## Quan trọng về đăng nhập nhiều thiết bị
Bản `index.html` hiện là bản chơi được để kiểm thử giao diện/game. Hồ sơ đang lưu bằng localStorage nên **chưa đồng bộ giữa các thiết bị**. File `supabase/schema.sql` là phần khởi tạo cơ sở dữ liệu tham khảo, chưa phải backend đăng nhập hoàn chỉnh. Không dùng bản này để thu thập tâm sự thật của học sinh hoặc phát hành rộng rãi trước khi hoàn tất backend.

Để phát hành đúng yêu cầu PIN + đồng bộ đa thiết bị, cần:
1. Tạo dự án Supabase.
2. Triển khai Edge Function xác thực nickname + PIN, hash PIN ở máy chủ, giới hạn số lần thử, cấp session có hạn dùng.
3. Chỉ cho session hợp lệ đọc/ghi hồ sơ và nhật ký của chính người chơi.
4. Thêm cấu hình Supabase vào ứng dụng.
5. Triển khai website lên Netlify hoặc Cloudflare Pages.

## Xuất bản bản chơi thử (chưa đồng bộ đa thiết bị)
1. Giải nén ZIP.
2. Mở https://app.netlify.com/drop
3. Kéo thả thư mục chứa `index.html`.
4. Netlify cấp một URL công khai dạng `....netlify.app`.

## Phím điều khiển
- Điện thoại: giữ ◀ / ▶, nhấn ⬆ để nhảy.
- Máy tính: A/D hoặc ←/→, Space để nhảy.

## An toàn cho học sinh
- Dùng biệt danh; không thu thập tên thật, số điện thoại, trường/lớp.
- Cần thông báo rõ ai có thể đọc nhật ký, thời hạn lưu, cách xóa dữ liệu.
- Cần quy trình hỗ trợ bởi người lớn có trách nhiệm nếu học sinh chia sẻ nguy cơ bị bạo lực hoặc tự làm hại.
- Không hứa hẹn bảo mật tuyệt đối; không dùng PIN ngắn làm cơ chế bảo vệ duy nhất.
